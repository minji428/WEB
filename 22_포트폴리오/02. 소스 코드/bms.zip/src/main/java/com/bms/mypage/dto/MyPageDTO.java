package com.bms.mypage.dto;

import org.springframework.stereotype.Component;

@Component("myPageDTO")
public class MyPageDTO {
	
	private String memberId;
	private String beginDate;
	private String endDate;
	
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	

}
